<?php 
include 'conexion.php';

$result= array();
$result['datos'] =array();
$query ="SELECT c.id, p.nombre AS producto, c.proveedor, c.cantidad, c.precio_compra, c.fecha 
         FROM compras c INNER JOIN productos p ON c.id_producto = p.id 
         ORDER BY c.fecha DESC";
$responce = mysqli_query($conexion,$query);

while($row = mysqli_fetch_array($responce))
{
    $index['id'] =$row['id'];
    $index['producto'] =$row['producto'];
    $index['proveedor'] =$row['proveedor'];
    $index['cantidad'] =$row['cantidad'];
    $index['precio_compra'] =$row['precio_compra'];
    $index['fecha'] =$row['fecha'];
    array_push($result['datos'], $index);
}
$result["exito"]="1";
echo json_encode($result);

?>