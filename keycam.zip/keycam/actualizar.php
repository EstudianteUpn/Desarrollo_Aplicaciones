<?php 
include 'conexion.php';

$id =$_POST['id'];
$nombre =$_POST['nombre'];
$id_categoria =$_POST['id_categoria'];
$precio =$_POST['precio'];
$stock =$_POST['stock'];
$stock_minimo =$_POST['stock_minimo'];
$urlimagen =$_POST['urlimagen'];

$query ="UPDATE productos SET nombre ='$nombre', id_categoria ='$id_categoria', precio ='$precio', stock ='$stock', stock_minimo ='$stock_minimo', urlimagen ='$urlimagen' WHERE id ='$id'";
$resultado =mysqli_query($conexion,$query);

if($resultado){
    echo "datos actualizados";
}else{
    echo "error en actualizacion";
}
mysqli_close($conexion);

?>