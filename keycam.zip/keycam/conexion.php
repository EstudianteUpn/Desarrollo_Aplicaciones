<?php
$conexion =mysqli_connect('localhost:3306','root','','bd_keycam');
if(!$conexion){
    echo "error en conexion";
}