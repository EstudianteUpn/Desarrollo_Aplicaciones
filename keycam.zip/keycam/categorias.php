<?php 
include 'conexion.php';

$result= array();
$result['datos'] =array();
$query ="SELECT * FROM categorias ORDER BY nombre ASC";
$responce = mysqli_query($conexion,$query);

while($row = mysqli_fetch_array($responce))
{
    $index['id'] =$row['id'];
    $index['nombre'] =$row['nombre'];
    array_push($result['datos'], $index);
}
$result["exito"]="1";
echo json_encode($result);

?>