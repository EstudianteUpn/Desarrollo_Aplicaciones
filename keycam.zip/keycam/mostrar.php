<?php 
include 'conexion.php';

$buscar = isset($_POST['buscar']) ? $_POST['buscar'] : '';
$categoria = isset($_POST['id_categoria']) ? $_POST['id_categoria'] : '0';

$result= array();
$result['datos'] =array();

$query ="SELECT p.*, c.nombre AS categoria FROM productos p 
         INNER JOIN categorias c ON p.id_categoria = c.id 
         WHERE p.estado = 1 AND p.nombre LIKE '%$buscar%'";
if($categoria != '0' && $categoria != ''){
    $query .= " AND p.id_categoria = '$categoria'";
}
$query .= " ORDER BY p.nombre ASC";

$responce = mysqli_query($conexion,$query);

while($row = mysqli_fetch_array($responce))
{
    $index['id'] =$row['id'];
    $index['nombre'] =$row['nombre'];
    $index['id_categoria'] =$row['id_categoria'];
    $index['categoria'] =$row['categoria'];
    $index['precio'] =$row['precio'];
    $index['stock'] =$row['stock'];
    $index['stock_minimo'] =$row['stock_minimo'];
    $index['urlimagen'] =$row['urlimagen'];
    $index['stock_bajo'] = ($row['stock'] <= $row['stock_minimo']) ? "1" : "0";
    array_push($result['datos'], $index);
}
$result["exito"]="1";
echo json_encode($result);

?>