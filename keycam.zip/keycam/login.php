<?php 
include 'conexion.php';

$usuario =$_POST['usuario'];
$clave =$_POST['clave'];

$result= array();
$result['datos'] =array();
$query ="SELECT * FROM usuarios WHERE usuario='$usuario' AND clave='$clave'";
$responce = mysqli_query($conexion,$query);

while($row = mysqli_fetch_array($responce))
{
    $index['id'] =$row['id'];
    $index['usuario'] =$row['usuario'];
    $index['rol'] =$row['rol'];
    array_push($result['datos'], $index);
}

if(count($result['datos']) > 0){
    $result["exito"]="1";
}else{
    $result["exito"]="0";
}
echo json_encode($result);

?>