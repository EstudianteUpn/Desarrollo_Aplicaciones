<?php 
include 'conexion.php';

$nombre =$_POST['nombre'];
$id_categoria =$_POST['id_categoria'];
$precio =$_POST['precio'];
$stock =$_POST['stock'];
$stock_minimo =$_POST['stock_minimo'];
$urlimagen =$_POST['urlimagen'];

$query ="INSERT INTO productos(nombre, id_categoria, precio, stock, stock_minimo, urlimagen) values('$nombre', '$id_categoria', '$precio', '$stock', '$stock_minimo', '$urlimagen')";
$resultado =mysqli_query($conexion,$query);

if($resultado){
    echo "datas insertados";
}else{
    echo "datas error";
}
mysqli_close($conexion);

?>