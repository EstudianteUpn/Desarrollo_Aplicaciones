package com.example.proyecto_aplicacionesmoviles.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.proyecto_aplicacionesmoviles.R;
import com.example.proyecto_aplicacionesmoviles.utils.constantes;
import com.example.proyecto_aplicacionesmoviles.utils.sesionmanager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    EditText etUsuario, etClave;
    Button btnIngresar;
    sesionmanager sesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sesion = new sesionmanager(this);

        // Si ya hay sesión guardada, saltar el login
        if (sesion.estaLogueado()) {
            irAlMenu();
            return;
        }

        setContentView(R.layout.activity_login);
        etUsuario = findViewById(R.id.etUsuario);
        etClave = findViewById(R.id.etClave);
        btnIngresar = findViewById(R.id.btnIngresar);

        btnIngresar.setOnClickListener(v -> login());
    }

    private void login() {
        String usuario = etUsuario.getText().toString().trim();
        String clave = etClave.getText().toString().trim();

        if (usuario.isEmpty() || clave.isEmpty()) {
            Toast.makeText(this, "Ingresa usuario y contraseña", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest req = new StringRequest(Request.Method.POST, constantes.URL_LOGIN,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        if (json.getString("exito").equals("1")) {
                            JSONObject u = json.getJSONArray("datos").getJSONObject(0);
                            sesion.iniciar(u.getInt("id"), u.getString("usuario"), u.getString("rol"));
                            irAlMenu();
                        } else {
                            Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Toast.makeText(this, "Respuesta inválida del servidor", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    String detalle;
                    if (error.networkResponse != null) {
                        detalle = "Código HTTP: " + error.networkResponse.statusCode;
                    } else {
                        detalle = error.getClass().getSimpleName();
                    }
                    Toast.makeText(this, "Error: " + detalle, Toast.LENGTH_LONG).show();
                })
                {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> p = new HashMap<>();
                p.put("usuario", usuario);
                p.put("clave", clave);
                return p;
            }
        };
        Volley.newRequestQueue(this).add(req);
    }

    private void irAlMenu() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}