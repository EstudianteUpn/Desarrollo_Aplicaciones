package com.example.proyecto_aplicacionesmoviles.activities;

import android.os.Bundle;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.example.proyecto_aplicacionesmoviles.R;
import com.example.proyecto_aplicacionesmoviles.models.categoria;
import com.example.proyecto_aplicacionesmoviles.models.producto;
import com.example.proyecto_aplicacionesmoviles.utils.constantes;
import com.example.proyecto_aplicacionesmoviles.utils.sesionmanager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductoFormActivity extends AppCompatActivity {

    TextView tvTitulo;
    EditText etNombre, etPrecio, etStock, etStockMinimo, etUrlImagen;
    ImageView ivPreview;
    Button btnGuardar;
    Spinner spCategoria;

    List<categoria> categorias = new ArrayList<>();
    ArrayAdapter<categoria> adapterCat;
    producto producto;   // null = registrar, con datos = editar

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Solo el administrador entra aquí
        if (!new sesionmanager(this).esAdmin()) {
            Toast.makeText(this, "Acceso solo para administrador", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setContentView(R.layout.activity_producto_form);
        tvTitulo = findViewById(R.id.tvTitulo);
        etNombre = findViewById(R.id.etNombre);
        etPrecio = findViewById(R.id.etPrecio);
        etStock = findViewById(R.id.etStock);
        etStockMinimo = findViewById(R.id.etStockMinimo);
        etUrlImagen = findViewById(R.id.etUrlImagen);
        ivPreview = findViewById(R.id.ivPreview);
        btnGuardar = findViewById(R.id.btnGuardar);
        spCategoria = findViewById(R.id.spCategoria);

        adapterCat = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categorias);
        spCategoria.setAdapter(adapterCat);

        // Modo editar: llenar los campos con los datos del producto
        producto = (producto) getIntent().getSerializableExtra("producto");
        if (producto != null) {
            tvTitulo.setText("Editar producto");
            etNombre.setText(producto.nombre);
            etPrecio.setText(String.valueOf(producto.precio));
            etStock.setText(String.valueOf(producto.stock));
            etStockMinimo.setText(String.valueOf(producto.stockMinimo));
            etUrlImagen.setText(producto.urlimagen);
            mostrarVistaPrevia();
        }

        // La vista previa se actualiza al pulsar "Listo" o al salir del campo
        etUrlImagen.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) mostrarVistaPrevia();
            return false;
        });
        etUrlImagen.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) mostrarVistaPrevia();
        });

        btnGuardar.setOnClickListener(v -> guardar());
        cargarCategorias();
    }

    private void mostrarVistaPrevia() {
        String url = constantes.urlImagen(etUrlImagen.getText().toString().trim());

        if (url.isEmpty()) {
            ivPreview.setImageResource(R.drawable.vacio);
            return;
        }

        Glide.with(this)
                .load(url)
                .placeholder(R.drawable.vacio)
                .error(R.drawable.vacio)
                .centerCrop()
                .into(ivPreview);
    }

    private void cargarCategorias() {
        StringRequest req = new StringRequest(Request.Method.POST, constantes.URL_CATEGORIAS,
                response -> {
                    try {
                        JSONArray datos = new JSONObject(response).getJSONArray("datos");
                        for (int i = 0; i < datos.length(); i++) {
                            JSONObject o = datos.getJSONObject(i);
                            categorias.add(new categoria(o.getInt("id"), o.getString("nombre")));
                        }
                        adapterCat.notifyDataSetChanged();

                        // En modo editar, dejar seleccionada la categoría actual
                        if (producto != null) {
                            for (int i = 0; i < categorias.size(); i++) {
                                if (categorias.get(i).id == producto.idCategoria) {
                                    spCategoria.setSelection(i);
                                }
                            }
                        }
                    } catch (JSONException e) {
                        Toast.makeText(this, "Error al leer categorías", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Error de conexión", Toast.LENGTH_SHORT).show());
        Volley.newRequestQueue(this).add(req);
    }

    private void guardar() {
        String nombre = etNombre.getText().toString().trim();
        String precio = etPrecio.getText().toString().trim();
        String stock = etStock.getText().toString().trim();
        String stockMin = etStockMinimo.getText().toString().trim();
        String url = etUrlImagen.getText().toString().trim();
        categoria cat = (categoria) spCategoria.getSelectedItem();

        if (nombre.isEmpty() || precio.isEmpty() || stock.isEmpty() || stockMin.isEmpty() || cat == null) {
            Toast.makeText(this, "Completa todos los campos obligatorios", Toast.LENGTH_SHORT).show();
            return;
        }

        String endpoint = (producto == null) ? constantes.URL_INSERTAR : constantes.URL_ACTUALIZAR;

        StringRequest req = new StringRequest(Request.Method.POST, endpoint,
                response -> {
                    if (response.toLowerCase().contains("error")) {
                        Toast.makeText(this, "No se pudo guardar", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Producto guardado", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                },
                error -> Toast.makeText(this, "Error de conexión", Toast.LENGTH_LONG).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> p = new HashMap<>();
                if (producto != null) p.put("id", String.valueOf(producto.id));
                p.put("nombre", nombre);
                p.put("id_categoria", String.valueOf(cat.id));
                p.put("precio", precio);
                p.put("stock", stock);
                p.put("stock_minimo", stockMin);
                p.put("urlimagen", url);
                return p;
            }
        };
        Volley.newRequestQueue(this).add(req);
    }
}