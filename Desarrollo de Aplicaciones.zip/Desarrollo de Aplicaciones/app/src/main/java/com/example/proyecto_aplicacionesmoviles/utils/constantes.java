package com.example.proyecto_aplicacionesmoviles.utils;

public class constantes {
    // Emulador: 10.0.2.2 | Celular físico: IP de tu PC (ipconfig)
    public static final String BASE_URL = "http://192.168.18.23/keycam/";

    public static final String URL_LOGIN      = BASE_URL + "login.php";
    public static final String URL_CATEGORIAS = BASE_URL + "categorias.php";
    public static final String URL_MOSTRAR    = BASE_URL + "mostrar.php";
    public static final String URL_INSERTAR   = BASE_URL + "insertar.php";
    public static final String URL_ACTUALIZAR = BASE_URL + "actualizar.php";
    public static final String URL_COMPRAS    = BASE_URL + "compras.php";

    // Acepta una ruta relativa ("imagenes/prod_1.jpg") o una URL completa ("http://...")
    public static String urlImagen(String ruta) {
        if (ruta == null || ruta.trim().isEmpty() || ruta.equals("null")) return "";
        if (ruta.startsWith("http")) return ruta;
        return BASE_URL + ruta;
    }
}