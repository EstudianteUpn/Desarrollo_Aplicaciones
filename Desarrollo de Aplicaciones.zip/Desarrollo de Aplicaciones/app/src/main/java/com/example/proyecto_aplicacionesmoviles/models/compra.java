package com.example.proyecto_aplicacionesmoviles.models;

public class compra {
    public String producto, proveedor, fecha;
    public int cantidad;
    public double precioCompra;
}