package com.example.proyecto_aplicacionesmoviles.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class sesionmanager {
    private final SharedPreferences sp;

    public sesionmanager(Context c) {
        sp = c.getSharedPreferences("keycam_sesion", Context.MODE_PRIVATE);
    }

    public void iniciar(int id, String usuario, String rol) {
        sp.edit().putInt("id", id).putString("usuario", usuario)
                .putString("rol", rol).putBoolean("logueado", true).apply();
    }

    public boolean estaLogueado() { return sp.getBoolean("logueado", false); }
    public String getUsuario()    { return sp.getString("usuario", ""); }
    public String getRol()        { return sp.getString("rol", ""); }
    public boolean esAdmin()      { return "administrador".equals(getRol()); }

    public void cerrar() { sp.edit().clear().apply(); }
}