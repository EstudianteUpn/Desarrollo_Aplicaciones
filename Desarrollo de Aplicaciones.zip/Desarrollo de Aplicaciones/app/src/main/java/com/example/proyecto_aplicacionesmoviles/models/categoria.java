package com.example.proyecto_aplicacionesmoviles.models;

public class categoria {
    public int id;
    public String nombre;

    public categoria(int id, String nombre) { this.id = id; this.nombre = nombre; }

    @Override public String toString() { return nombre; }  // lo usa el Spinner
}