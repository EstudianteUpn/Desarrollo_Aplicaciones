package com.example.proyecto_aplicacionesmoviles.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.proyecto_aplicacionesmoviles.R;
import com.example.proyecto_aplicacionesmoviles.adapters.ProductoAdapter;
import com.example.proyecto_aplicacionesmoviles.models.categoria;
import com.example.proyecto_aplicacionesmoviles.models.producto;
import com.example.proyecto_aplicacionesmoviles.utils.constantes;
import com.example.proyecto_aplicacionesmoviles.utils.sesionmanager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ListarActivity extends AppCompatActivity {

    EditText etBuscar;
    Spinner spCategoria;
    RecyclerView rvProductos;

    List<producto> productos = new ArrayList<>();
    List<categoria> categorias = new ArrayList<>();
    ProductoAdapter adapter;
    ArrayAdapter<categoria> adapterCat;
    sesionmanager sesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar);
        sesion = new sesionmanager(this);

        etBuscar = findViewById(R.id.etBuscar);
        spCategoria = findViewById(R.id.spCategoria);
        rvProductos = findViewById(R.id.rvProductos);

        // Adapter de productos: solo el administrador puede editar (HU04)
        adapter = new ProductoAdapter(productos, p -> {
            if (sesion.esAdmin()) {
                Intent i = new Intent(this, ProductoFormActivity.class);
                i.putExtra("producto", p);
                startActivity(i);
            } else {
                Toast.makeText(this, "Solo el administrador puede editar", Toast.LENGTH_SHORT).show();
            }
        });
        rvProductos.setLayoutManager(new LinearLayoutManager(this));
        rvProductos.setAdapter(adapter);

        // Spinner con "Todas" como primera opción
        categorias.add(new categoria(0, "Todas"));
        adapterCat = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categorias);
        spCategoria.setAdapter(adapterCat);

        spCategoria.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cargarProductos();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        etBuscar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { cargarProductos(); }
            @Override public void afterTextChanged(Editable s) { }
        });

        cargarCategorias();
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarProductos();   // refresca al volver de editar
    }

    private void cargarCategorias() {
        StringRequest req = new StringRequest(Request.Method.POST, constantes.URL_CATEGORIAS,
                response -> {
                    try {
                        JSONArray datos = new JSONObject(response).getJSONArray("datos");
                        for (int i = 0; i < datos.length(); i++) {
                            JSONObject o = datos.getJSONObject(i);
                            categorias.add(new categoria(o.getInt("id"), o.getString("nombre")));
                        }
                        adapterCat.notifyDataSetChanged();
                    } catch (JSONException e) {
                        Toast.makeText(this, "Error al leer categorías", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Error de conexión", Toast.LENGTH_SHORT).show());
        Volley.newRequestQueue(this).add(req);
    }

    // HU06: buscar por nombre y filtrar por categoría
    private void cargarProductos() {
        categoria sel = (categoria) spCategoria.getSelectedItem();
        String idCat = sel == null ? "0" : String.valueOf(sel.id);
        String buscar = etBuscar.getText().toString().trim();

        StringRequest req = new StringRequest(Request.Method.POST, constantes.URL_MOSTRAR,
                response -> {
                    try {
                        JSONArray datos = new JSONObject(response).getJSONArray("datos");
                        productos.clear();
                        for (int i = 0; i < datos.length(); i++) {
                            JSONObject o = datos.getJSONObject(i);
                            producto p = new producto();
                            p.id = o.getInt("id");
                            p.nombre = o.getString("nombre");
                            p.idCategoria = o.getInt("id_categoria");
                            p.categoria = o.getString("categoria");
                            p.precio = o.getDouble("precio");
                            p.stock = o.getInt("stock");
                            p.stockMinimo = o.getInt("stock_minimo");
                            p.urlimagen = o.getString("urlimagen");
                            p.stockBajo = o.getString("stock_bajo").equals("1");   // HU15
                            productos.add(p);
                        }
                        adapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        Toast.makeText(this, "Error al leer productos", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Error de conexión", Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> p = new HashMap<>();
                p.put("buscar", buscar);
                p.put("id_categoria", idCat);
                return p;
            }
        };
        Volley.newRequestQueue(this).add(req);
    }
}