package com.example.proyecto_aplicacionesmoviles.activities;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.proyecto_aplicacionesmoviles.R;
import com.example.proyecto_aplicacionesmoviles.models.compra;
import com.example.proyecto_aplicacionesmoviles.utils.constantes;
import com.example.proyecto_aplicacionesmoviles.utils.sesionmanager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ComprasActivity extends AppCompatActivity {

    ListView lvCompras;
    List<compra> compras = new ArrayList<>();
    ArrayAdapter<compra> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!new sesionmanager(this).esAdmin()) {
            Toast.makeText(this, "Acceso solo para administrador", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setContentView(R.layout.activity_compras);
        lvCompras = findViewById(R.id.lvCompras);

        adapter = new ArrayAdapter<compra>(this, android.R.layout.simple_list_item_2,
                android.R.id.text1, compras) {
            @Override
            public View getView(int pos, View convertView, ViewGroup parent) {
                View v = super.getView(pos, convertView, parent);
                compra c = getItem(pos);
                ((TextView) v.findViewById(android.R.id.text1)).setText(c.producto + " · " + c.proveedor);
                ((TextView) v.findViewById(android.R.id.text2)).setText(
                        "Cantidad: " + c.cantidad + " · S/ " + String.format("%.2f", c.precioCompra) + " · " + c.fecha);
                return v;
            }
        };
        lvCompras.setAdapter(adapter);

        cargarCompras();
    }

    private void cargarCompras() {
        StringRequest req = new StringRequest(Request.Method.POST, constantes.URL_COMPRAS,
                response -> {
                    try {
                        JSONArray datos = new JSONObject(response).getJSONArray("datos");
                        compras.clear();
                        for (int i = 0; i < datos.length(); i++) {
                            JSONObject o = datos.getJSONObject(i);
                            compra c = new compra();
                            c.producto = o.getString("producto");
                            c.proveedor = o.getString("proveedor");
                            c.cantidad = o.getInt("cantidad");
                            c.precioCompra = o.getDouble("precio_compra");
                            c.fecha = o.getString("fecha");
                            compras.add(c);
                        }
                        adapter.notifyDataSetChanged();
                        if (compras.isEmpty()) {
                            Toast.makeText(this, "Aún no hay compras registradas", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Toast.makeText(this, "Error al leer compras", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Error de conexión", Toast.LENGTH_SHORT).show());
        Volley.newRequestQueue(this).add(req);
    }
}