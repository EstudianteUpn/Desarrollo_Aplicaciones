package com.example.proyecto_aplicacionesmoviles.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.proyecto_aplicacionesmoviles.R;
import com.example.proyecto_aplicacionesmoviles.models.producto;
import com.example.proyecto_aplicacionesmoviles.utils.constantes;
import com.google.android.material.chip.Chip;

import java.util.List;

public class ProductoAdapter extends RecyclerView.Adapter<ProductoAdapter.VH> {

    public interface OnItemClick { void onClick(producto p); }

    private final List<producto> lista;
    private final OnItemClick listener;

    public ProductoAdapter(List<producto> lista, OnItemClick listener) {
        this.lista = lista;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_producto, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        producto p = lista.get(position);

        h.tvNombre.setText(p.nombre);
        h.tvCategoria.setText(p.categoria);
        h.tvPrecio.setText("S/ " + String.format("%.2f", p.precio));
        h.tvStock.setText("Stock: " + p.stock + " (mínimo " + p.stockMinimo + ")");

        // HU15: chip y color rojo cuando el stock es bajo
        h.chipStockBajo.setVisibility(p.stockBajo ? View.VISIBLE : View.GONE);
        int color = p.stockBajo ? R.color.keycam_danger : R.color.keycam_text_light;
        h.tvStock.setTextColor(ContextCompat.getColor(h.itemView.getContext(), color));

        // Foto del producto (urlimagen)
        Glide.with(h.itemView.getContext())
                .load(constantes.urlImagen(p.urlimagen))
                .placeholder(R.drawable.vacio) // se cambiaaaaaaaaaaaaaaa
                .error(R.drawable.vacio) //se cambiaaaaaaaa
                .centerCrop()
                .into(h.ivProducto);

        h.itemView.setOnClickListener(v -> listener.onClick(p));
    }

    @Override
    public int getItemCount() { return lista.size(); }

    static class VH extends RecyclerView.ViewHolder {
        ImageView ivProducto;
        TextView tvNombre, tvCategoria, tvPrecio, tvStock;
        Chip chipStockBajo;

        VH(@NonNull View itemView) {
            super(itemView);
            ivProducto = itemView.findViewById(R.id.ivProducto);
            tvNombre = itemView.findViewById(R.id.tvNombre);
            tvCategoria = itemView.findViewById(R.id.tvCategoria);
            tvPrecio = itemView.findViewById(R.id.tvPrecio);
            tvStock = itemView.findViewById(R.id.tvStock);
            chipStockBajo = itemView.findViewById(R.id.chipStockBajo);
        }
    }
}