package com.example.proyecto_aplicacionesmoviles.models;

import java.io.Serializable;

public class producto implements Serializable {
    public int id, idCategoria, stock, stockMinimo;
    public String nombre, categoria, urlimagen;
    public double precio;
    public boolean stockBajo;
}