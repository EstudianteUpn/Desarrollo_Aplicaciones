package com.example.proyecto_aplicacionesmoviles.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.chip.Chip;
import com.example.proyecto_aplicacionesmoviles.R;
import com.example.proyecto_aplicacionesmoviles.utils.constantes;
import com.example.proyecto_aplicacionesmoviles.utils.sesionmanager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    TextView tvBienvenida;
    Chip chipAlerta;
    Button btnProductos, btnNuevo, btnCompras, btnCerrar;
    sesionmanager sesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sesion = new sesionmanager(this);

        if (!sesion.estaLogueado()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_main);
        tvBienvenida = findViewById(R.id.tvBienvenida);
        chipAlerta = findViewById(R.id.chipAlerta);
        btnProductos = findViewById(R.id.btnProductos);
        btnNuevo = findViewById(R.id.btnNuevo);
        btnCompras = findViewById(R.id.btnCompras);
        btnCerrar = findViewById(R.id.btnCerrar);

        tvBienvenida.setText("Hola, " + sesion.getUsuario() + " (" + sesion.getRol() + ")");

        // Solo el administrador ve estas opciones
        if (!sesion.esAdmin()) {
            btnNuevo.setVisibility(View.GONE);
            btnCompras.setVisibility(View.GONE);
        }

        btnProductos.setOnClickListener(v -> startActivity(new Intent(this, ListarActivity.class)));
        chipAlerta.setOnClickListener(v -> startActivity(new Intent(this, ListarActivity.class)));
        btnNuevo.setOnClickListener(v -> startActivity(new Intent(this, ProductoFormActivity.class)));
        btnCompras.setOnClickListener(v -> startActivity(new Intent(this, ComprasActivity.class)));
        btnCerrar.setOnClickListener(v -> confirmarCierre());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (sesion.estaLogueado()) contarStockBajo();
    }

    // HU15: contar productos con stock bajo y mostrarlo en un chip
    private void contarStockBajo() {
        StringRequest req = new StringRequest(Request.Method.POST, constantes.URL_MOSTRAR,
                response -> {
                    try {
                        JSONArray datos = new JSONObject(response).getJSONArray("datos");
                        int bajos = 0;
                        for (int i = 0; i < datos.length(); i++) {
                            if (datos.getJSONObject(i).getString("stock_bajo").equals("1")) bajos++;
                        }
                        if (bajos > 0) {
                            chipAlerta.setText(bajos + " producto(s) con stock bajo");
                            chipAlerta.setVisibility(View.VISIBLE);
                        } else {
                            chipAlerta.setVisibility(View.GONE);
                        }
                    } catch (JSONException e) {
                        chipAlerta.setVisibility(View.GONE);
                    }
                },
                error -> chipAlerta.setVisibility(View.GONE));
        Volley.newRequestQueue(this).add(req);
    }

    // HU02: cerrar sesión
    private void confirmarCierre() {
        new AlertDialog.Builder(this)
                .setTitle("Cerrar sesión")
                .setMessage("¿Deseas salir de la aplicación?")
                .setPositiveButton("Sí", (d, w) -> {
                    sesion.cerrar();
                    Intent i = new Intent(this, LoginActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }
}